/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.PriorityQueue;

/**
 *
 * @author sistemas
 */
public abstract class Grafo 
{
    private boolean dirigido;
    private ArrayList<Vertice> vertices;

    public Grafo(boolean dirigido, ArrayList<Vertice> vertices) 
    {
        this.dirigido = dirigido;
        this.vertices = vertices;
    }
    
    public boolean isDirigido() {
        return dirigido;
    }

    public ArrayList<Vertice> getVertices() {
        return vertices;
    }

    public void setDirigido(boolean dirigido) {
        this.dirigido = dirigido;
    }

    public void setVertices(ArrayList<Vertice> vertices) {
        this.vertices = vertices;
    }
    
    public abstract ArrayList<Vertice> vecinos (Vertice v);
    
    public abstract Integer costoArista (Vertice a, Vertice b);
    
    public void explorar(Vertice v, int num)
    {
        v.setEtiqueta(num);
        
        for (Vertice vecino : vecinos(v)) 
        {
            if(vecino.getEtiqueta() == 0)
            {
                explorar(vecino, num);
            }
        }
    }
    
    public void dfs()
    {
        int num = 1;
        
        for (Vertice v : vertices) 
        {
            if(v.getEtiqueta() == 0)
            {
                explorar(v, num);
                num++;
            }
        }
    }
    
    public boolean hayCamino (Vertice v1, Vertice v2)
    {
        boolean bandera = false;
        
        if(v1.getEtiqueta() == v2.getEtiqueta())
        {
            bandera = true;
        }
        return bandera;
    }
    
    public Map<Vertice, Integer> bfs (Vertice s) // Sin pesos
    {
        Integer infinito = Integer.MAX_VALUE;
        
        Queue <Vertice> cola = new LinkedList<>();
        
        Map<Vertice, Integer> dist = new HashMap<>();
        
        for (Vertice v : vertices) 
        {
            dist.put(v, infinito);
        }
        dist.replace(s, 0);
        cola.add(s);
        
        while(!cola.isEmpty())
        {
            Vertice u = cola.remove();
            
            for (Vertice v : vecinos(u)) 
            {
                if(dist.get(v).equals(infinito))
                {
                    cola.add(v);
                    dist.replace(v, (dist.get(u) + 1) );
                }
            }    
        }
        return dist;
    }
    
    public Map<Vertice, Integer> dijkstra (Vertice s)
    {
        Integer infinito = Integer.MAX_VALUE;
        
        Map<Vertice, Integer> dist = new HashMap<>();
        Map<Vertice, Vertice> pred = new HashMap<>();
        
        ColaPrioridad cola = new ColaPrioridad(dist);   //Cola de Prioridad con los dist
        
        for (Vertice v : vertices) 
        {
            dist.put(v, infinito);
            pred.put(v, null);
            cola.añadir(v);
        }
        dist.replace(s, 0);
        cola.actualizar();
        
        while(!cola.isEmpty())
        {
            Vertice u = cola.minimo(); //Remover el minimo
            for (Vertice v : vecinos(u)) 
            {
                if(dist.get(v) > (dist.get(u) + costoArista(u, v)))
                {
                    dist.replace(v, dist.get(u)+ costoArista(u, v));
                    pred.replace(v, u);
                    cola.actualizar();
                }
            }
        }
        return dist;
    }
    
    public boolean bellmanFord (Vertice s)
    {
        Integer infinito = Integer.MAX_VALUE;
        
        Queue <Vertice> cola = new LinkedList<>();
        
        Map<Vertice, Integer> dist = new HashMap<>();
        Map<Vertice, Vertice> pred = new HashMap<>();
        
        for (Vertice v : vertices) 
        {
            dist.put(v, infinito);
            pred.put(v, null);
        }
        dist.replace(s, 0);
        
        for (int i = 1; i < vertices.size(); i++) 
        {
            cola.add(s);
            while(!cola.isEmpty())
            {
                Vertice u = cola.remove();
                for (Vertice v : vecinos(u)) 
                {
                    if(dist.get(v)> dist.get(u)+ costoArista(u, v))
                    {
                        cola.add(v);
                        dist.replace(v, dist.get(u)+ costoArista(u, v));
                        pred.put(v, u);
                    }
                }    
            }
        }
        boolean bandera = true;
        cola.add(s);
        while(!cola.isEmpty())
        {
            Vertice u = cola.remove();
            for (Vertice v : vecinos(u)) 
            {
                if(dist.get(v)> dist.get(u)+ costoArista(u, v))
                {
                    cola.add(v);
                    System.out.println("Hay ciclo negativo");
                    bandera = false;
                }
            }    
        }
        return bandera;     
    }
    
    public Map<Vertice, Vertice> Prim (Vertice s)
    {
        Integer infinito = Integer.MAX_VALUE;
        
        Map<Vertice, Integer> dist = new HashMap<>();
        Map<Vertice, Vertice> padres = new HashMap<>();
        
        ColaPrioridad cola = new ColaPrioridad(dist);
        
        for (Vertice v : vertices) 
        {
            dist.put(v, infinito);
            padres.put(v, null);
            cola.añadir(v);
        }
        dist.replace(s, 0);
        cola.actualizar();
        
        while(!cola.isEmpty())
        {
            Vertice u = cola.minimo();
            for (Vertice v : vecinos(u)) 
            {
                if(cola.pertenece(v) && (dist.get(v) > costoArista(u, v)))
                {
                    padres.replace(v, u);
                    dist.replace(v, costoArista(u, v));
                    cola.actualizar();
                }
            }
        } 
        return padres;
    }
    
    
    
}
